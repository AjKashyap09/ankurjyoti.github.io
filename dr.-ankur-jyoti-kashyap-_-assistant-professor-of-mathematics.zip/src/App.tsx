import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Navbar, Footer } from "@/src/components/Navigation";
import Home from "@/src/pages/Home";
import PersonalInfo from "@/src/pages/PersonalInfo";
import Research from "@/src/pages/Research";
import Publications from "@/src/pages/Publications";
import Presentations from "@/src/pages/Presentations";
import Highlights from "@/src/pages/Highlights";
import Assignments from "@/src/pages/Assignments";
import Contact from "@/src/pages/Contact";

// Scroll to top on route change
function ScrollToTop() {
  const { pathname } = useLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  
  return null;
}

export default function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/personal" element={<PersonalInfo />} />
            <Route path="/research" element={<Research />} />
            <Route path="/publications" element={<Publications />} />
            <Route path="/presentations" element={<Presentations />} />
            <Route path="/highlights" element={<Highlights />} />
            <Route path="/assignments" element={<Assignments />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}
