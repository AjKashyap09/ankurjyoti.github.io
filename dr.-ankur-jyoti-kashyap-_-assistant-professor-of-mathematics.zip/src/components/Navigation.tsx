import { Link, useLocation } from "react-router-dom";
import { motion } from "motion/react";
import { Menu, X, BookOpen, GraduationCap, Mail, Newspaper, Presentation, User, CheckCircle2, Star } from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/src/lib/utils";

const navItems = [
  { name: "Home", path: "/", icon: GraduationCap },
  { name: "Personal", path: "/personal", icon: User },
  { name: "Research", path: "/research", icon: BookOpen },
  { name: "Publications", path: "/publications", icon: Newspaper },
  { name: "Highlights", path: "/highlights", icon: Star },
  { name: "Presentations", path: "/presentations", icon: Presentation },
  { name: "Assignments", path: "/assignments", icon: CheckCircle2 },
  { name: "Contact", path: "/contact", icon: Mail },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4",
        scrolled ? "bg-white/80 backdrop-blur-md shadow-sm py-2" : "bg-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex flex-col">
          <span className="font-serif text-xl font-bold tracking-tight text-academic-navy">
            Dr. Ankur Jyoti Kashyap
          </span>
          <span className="text-[10px] uppercase tracking-widest text-academic-gold font-semibold">
            Assistant Professor of Mathematics
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "text-sm font-medium transition-colors hover:text-academic-gold",
                location.pathname === item.path
                  ? "text-academic-gold border-b border-academic-gold"
                  : "text-slate-600"
              )}
            >
              {item.name}
            </Link>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-academic-navy p-2"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Nav */}
      <motion.div
        initial={false}
        animate={isOpen ? { height: "auto", opacity: 1 } : { height: 0, opacity: 0 }}
        className="md:hidden overflow-hidden bg-white mt-4 rounded-2xl shadow-xl"
      >
        <div className="flex flex-col p-6 space-y-4">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setIsOpen(false)}
              className={cn(
                "flex items-center space-x-3 text-lg font-medium py-2 px-4 rounded-lg transition-colors",
                location.pathname === item.path
                  ? "bg-academic-navy text-white text-academic-gold"
                  : "text-slate-600 hover:bg-slate-50"
              )}
            >
              <item.icon size={20} />
              <span>{item.name}</span>
            </Link>
          ))}
        </div>
      </motion.div>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="bg-academic-navy text-white py-12 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
        <div>
          <h3 className="font-serif text-2xl font-bold mb-4">Dr. Ankur Jyoti Kashyap</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Assistant Professor, Department of Mathematics,<br />
            Girijananda Chowdhury University,<br />
            Hatkhowapara, Azara, Guwahati-17, Assam.
          </p>
        </div>
        <div>
          <h4 className="text-academic-gold uppercase text-xs font-bold tracking-widest mb-6">Quick Links</h4>
          <ul className="space-y-3 text-sm">
            {navItems.map((item) => (
              <li key={item.path}>
                <Link to={item.path} className="text-slate-400 hover:text-white transition-colors">
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-academic-gold uppercase text-xs font-bold tracking-widest mb-6">Contact</h4>
          <ul className="space-y-3 text-sm text-slate-400">
            <li className="flex items-center space-x-2">
              <Mail size={16} />
              <span>ajkashyap.maths@gmail.com</span>
            </li>
            <li>Girijananda Chowdhury University, Guwahati</li>
          </ul>
        </div>
      </div>
      <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-xs text-slate-500">
          &copy; {new Date().getFullYear()} Dr. Ankur Jyoti Kashyap. All rights reserved.
        </p>
        <div className="flex items-center gap-3 bg-white/5 py-1.5 px-4 rounded-full border border-white/10 group hover:bg-white/10 transition-all">
          <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 group-hover:text-academic-gold transition-colors">Visitor Count</span>
          <img 
            src="https://hits.dwyl.com/ajkashyap/academic-portfolio.svg" 
            alt="Hit Count" 
            className="h-5 opacity-80"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>
    </footer>
  );
}
