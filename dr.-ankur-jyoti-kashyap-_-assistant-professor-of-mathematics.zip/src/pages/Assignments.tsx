import { motion } from "motion/react";
import { CheckCircle2, Building, Hash, BookOpenCheck, GraduationCap, School } from "lucide-react";

const reviewerAssignments = [
  {
    journal: "International Journal of Biomathematics",
    publisher: "World Scientific",
    count: "04"
  },
  {
    journal: "Mathematical Modelling and Control",
    publisher: "AIMS",
    count: "01"
  },
  {
    journal: "Results in Control and Optimization",
    publisher: "Elsevier",
    count: "01"
  },
  {
    journal: "Computer Methods in Biomechanics and Biomedical Engineering",
    publisher: "Taylor & Francis",
    count: "01"
  },
  {
    journal: "Computational and Applied Mathematics",
    publisher: "Springer",
    count: "01"
  }
];

const teachingAssignments = [
  {
    level: "Undergraduate (UG)",
    icon: School,
    courses: [
      "Differential Equations",
      "Numerical Methods",
      "Real Analysis",
      "Probability and Statistics",
      "Engineering Mathematics",
      "R-Programming",
      "MATLAB Programming"
    ]
  },
  {
    level: "Postgraduate (PG)",
    icon: GraduationCap,
    courses: [
      "Nonlinear Dynamics",
      "Functional Analysis",
      "Linear Algebra",
      "LaTeX and HTML",
      "Mathematica",
      "Dynamical Systems",
      "ODE-PDE-LAB",
      "Projects"
    ]
  },
  {
    level: "Ph.D. Coursework",
    icon: BookOpenCheck,
    courses: [
      "Dynamical Systems",
      "Review Paper"
    ]
  }
];

export default function Assignments() {
  return (
    <div className="pt-32 pb-24 px-6 bg-[#FAFAFA]">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-20 text-center"
        >
          <span className="text-academic-gold font-bold uppercase text-xs tracking-widest mb-4 inline-block">Academic Roles</span>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-academic-navy mb-6">Assignments</h1>
          <p className="text-slate-500 max-w-2xl mx-auto">
            Comprehensive overview of reviewer contributions and teaching responsibilities across various academic levels.
          </p>
        </motion.div>

        {/* Reviewer Assignments Section */}
        <section className="mb-24">
          <div className="flex items-center gap-4 mb-12">
            <div className="h-px flex-grow bg-slate-200"></div>
            <h2 className="font-serif text-3xl font-bold text-academic-navy px-4">Reviewer Assignments</h2>
            <div className="h-px flex-grow bg-slate-200"></div>
          </div>
          
          <div className="grid grid-cols-1 gap-6">
            {reviewerAssignments.map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="group bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col md:flex-row md:items-center justify-between gap-6"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 rounded-full bg-academic-gold/10 flex items-center justify-center text-academic-gold">
                      <CheckCircle2 size={18} />
                    </div>
                    <span className="text-xs font-bold text-academic-navy/40 uppercase tracking-widest">Journal Reviewer</span>
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-academic-navy mb-2 group-hover:text-academic-gold transition-colors">
                    {item.journal}
                  </h3>
                  <div className="flex items-center gap-2 text-slate-500 text-sm">
                    <Building size={16} className="text-slate-300" />
                    {item.publisher}
                  </div>
                </div>

                <div className="flex items-center gap-4 bg-slate-50 px-6 py-4 rounded-2xl border border-slate-100 group-hover:bg-academic-navy group-hover:border-academic-navy transition-all">
                  <div className="text-right">
                    <span className="block text-[10px] uppercase tracking-tighter text-slate-400 group-hover:text-white/60">Reviews</span>
                    <span className="block text-2xl font-bold text-academic-navy group-hover:text-academic-gold">{item.count}</span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-academic-gold shadow-sm">
                    <Hash size={20} />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Teaching Assignments Section */}
        <section>
          <div className="flex items-center gap-4 mb-12">
            <div className="h-px flex-grow bg-slate-200"></div>
            <h2 className="font-serif text-3xl font-bold text-academic-navy px-4">Teaching Assignments</h2>
            <div className="h-px flex-grow bg-slate-200"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {teachingAssignments.map((category, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-lg transition-all"
              >
                <div className="w-14 h-14 bg-academic-navy text-academic-gold rounded-2xl flex items-center justify-center mb-6 shadow-inner">
                  <category.icon size={28} />
                </div>
                <h3 className="font-serif text-2xl font-bold text-academic-navy mb-6 pb-4 border-b border-slate-100">
                  {category.level}
                </h3>
                <ul className="space-y-4">
                  {category.courses.map((course, cIdx) => (
                    <li key={cIdx} className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-academic-gold mt-2 shrink-0"></div>
                      <span className="text-slate-600 text-sm leading-tight">{course}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </section>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-24 p-8 bg-academic-navy rounded-[2.5rem] text-center text-white relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-full opacity-5 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px]"></div>
          <p className="relative z-10 text-slate-300 italic text-lg">
            "Education is not the learning of facts, but the training of the mind to think."
          </p>
        </motion.div>
      </div>
    </div>
  );
}
