import { motion } from "motion/react";
import { Mail, Phone, MapPin, Send, MessageSquare, Globe, ExternalLink, Search, Share2, Database, CheckCircle } from "lucide-react";
import { useState, FormEvent } from "react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // In a real app, you'd send the form data here
  };

  const researchProfiles = [
    { name: "ResearchGate", url: "https://www.researchgate.net/profile/Ankur_Kashyap5", icon: Share2 },
    { name: "Web of Science", url: "https://www.webofscience.com/wos/author/record/AAU-2132-2021", icon: Search },
    { name: "Scopus", url: "http://www.scopus.com/inward/authorDetails.url?authorID=57220578083&partnerID=MN8TOARS", icon: Database },
    { name: "ORCID", url: "https://orcid.org/0000-0002-7827-3290", icon: CheckCircle },
  ];

  return (
    <div className="pt-32 pb-24 px-6 bg-[#FDFCFB]">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <span className="text-academic-gold font-bold uppercase text-xs tracking-widest mb-4 inline-block">Connect</span>
            <h1 className="font-serif text-5xl md:text-6xl font-bold text-academic-navy mb-8">Get in Touch</h1>
            <p className="text-slate-600 text-lg mb-12 leading-relaxed">
              For academic inquiries, collaboration proposals, or student mentorship questions, please use the contact information below or fill out the message form.
            </p>

            <div className="space-y-8">
              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-white shadow-sm border border-slate-100 rounded-2xl flex items-center justify-center text-academic-gold flex-shrink-0">
                  <Mail size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-academic-navy mb-1">Email Address</h3>
                  <a href="mailto:ajkashyap.maths@gmail.com" className="text-slate-500 hover:text-academic-gold transition-colors">
                    ajkashyap.maths@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-white shadow-sm border border-slate-100 rounded-2xl flex items-center justify-center text-academic-gold flex-shrink-0">
                  <Phone size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-academic-navy mb-1">Mobile</h3>
                  <p className="text-slate-500">
                    +91 8011180712
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-white shadow-sm border border-slate-100 rounded-2xl flex items-center justify-center text-academic-gold flex-shrink-0">
                  <MapPin size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-academic-navy mb-1">Office Location</h3>
                  <p className="text-slate-500">
                    Dept. of Mathematics, Girijananda Chowdhury University,<br />
                    Azara, Guwahati-17, Assam
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-white shadow-sm border border-slate-100 rounded-2xl flex items-center justify-center text-academic-gold flex-shrink-0">
                  <Globe size={24} />
                </div>
                <div className="w-full">
                  <h3 className="font-bold text-academic-navy mb-3">Academic Profiles</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {researchProfiles.map((profile) => (
                      <a 
                        key={profile.name}
                        href={profile.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 px-4 py-3 bg-white border border-slate-100 rounded-xl text-sm text-slate-600 hover:border-academic-gold hover:text-academic-gold transition-all shadow-sm group"
                      >
                        <profile.icon size={18} className="text-slate-400 group-hover:text-academic-gold transition-colors" />
                        <span className="flex-1">{profile.name}</span>
                        <ExternalLink size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="w-12 h-12 bg-white shadow-sm border border-slate-100 rounded-2xl flex items-center justify-center text-academic-gold flex-shrink-0">
                  <MessageSquare size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-academic-navy mb-1">Consultation Hours</h3>
                  <p className="text-slate-500">Monday - Friday: 10:00 AM - 4:00 PM</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white p-10 md:p-12 rounded-[3rem] shadow-xl border border-slate-50"
          >
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-20">
                <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mb-6">
                  <Send size={40} />
                </div>
                <h2 className="font-serif text-3xl font-bold text-academic-navy mb-4">Message Sent</h2>
                <p className="text-slate-500">Thank you for reaching out. Dr. Kashyap will get back to you shortly.</p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="mt-8 text-academic-gold font-bold hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-400 ml-1">Full Name</label>
                    <input 
                      required
                      type="text" 
                      placeholder="Your Name"
                      className="w-full px-6 py-4 bg-slate-50 border border-transparent rounded-2xl focus:bg-white focus:border-academic-gold outline-none transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-400 ml-1">Email Address</label>
                    <input 
                      required
                      type="email" 
                      placeholder="email@example.com"
                      className="w-full px-6 py-4 bg-slate-50 border border-transparent rounded-2xl focus:bg-white focus:border-academic-gold outline-none transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400 ml-1">Subject</label>
                  <input 
                    required
                    type="text" 
                    placeholder="Inquiry Subject"
                    className="w-full px-6 py-4 bg-slate-50 border border-transparent rounded-2xl focus:bg-white focus:border-academic-gold outline-none transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400 ml-1">Message</label>
                  <textarea 
                    required
                    rows={5}
                    placeholder="Tell me more about how I can help..."
                    className="w-full px-6 py-4 bg-slate-50 border border-transparent rounded-2xl focus:bg-white focus:border-academic-gold outline-none transition-all resize-none"
                  ></textarea>
                </div>

                <button 
                  type="submit"
                  className="w-full py-5 bg-academic-navy text-white font-bold rounded-2xl hover:bg-academic-gold transition-all flex items-center justify-center gap-3 group"
                >
                  Send Message
                  <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </button>
              </form>
            )}
          </motion.div>
        </div>

        {/* Map Section */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-24 h-96 bg-slate-200 rounded-[3rem] overflow-hidden relative shadow-2xl border-4 border-white"
        >
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3582.0245647565155!2d91.6200000!3d26.133310!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x375a034293f773b9%3A0xc3afbf466870df22!2sGirijananda%20Chowdhury%20University!5e0!3m2!1sen!2sin!4v1715286500000!5m2!1sen!2sin&maptype=satellite" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen={true} 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            title="Girijananda Chowdhury University Satellite View"
            className="grayscale-[20%] contrast-[1.1] brightness-[0.9]"
          ></iframe>
          <a 
            href="https://maps.app.goo.gl/dXVjPE2vMce3Acdp6" 
            target="_blank" 
            rel="noopener noreferrer"
            className="absolute top-6 left-6 bg-white/90 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-white flex items-center gap-2 hover:bg-white hover:scale-105 transition-all cursor-pointer group"
          >
            <div className="w-2 h-2 rounded-full bg-academic-gold animate-pulse"></div>
            <span className="text-xs font-bold text-academic-navy uppercase tracking-widest group-hover:text-academic-gold transition-colors">Live Campus View</span>
          </a>
        </motion.div>
      </div>
    </div>
  );
}
