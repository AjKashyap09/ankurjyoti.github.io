import { motion } from "motion/react";
import { Star, FileText, ExternalLink, User, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const highlights = [
  {
    title: "A Mathematical–Dynamical Framework for Coral–Zooxanthellae Interactions under Vibrio-Induced Bleaching",
    journal: "Chinese Journal of Physics",
    year: "2026",
    authors: "Suruj Lekharu, Ankur Jyoti Kashyap",
    doi: "10.1016/j.cjph.2026.04.040",
    description: "Highly relevant research addressing climate-induced coral bleaching through the lens of nonlinear dynamics."
  },
  {
    title: "Deterministic study of an Eco-epidemiological Model with Prey Refuge and Predator Harvesting",
    journal: "Boletim Da Sociedade Paranaense de Matemática",
    year: "2026",
    authors: "Kahuwa Kuwali Barman, Ankur Jyoti Kashyap, Hemanta Kumar Sarmah",
    doi: "10.5269/bspm.81950",
    description: "An investigation into ecosystem stability and disease spread within harvested populations."
  },
  {
    title: "Dynamical Analysis of a Leslie-Gower Type Harvesting Model Incorporating Nonlinear Harvesting and Fear Effect",
    journal: "Boletim Da Sociedade Paranaense de Matemática",
    year: "2026",
    authors: "Ankur Jyoti Kashyap, Suruj Lekharu, Tarini Kumar Dutta",
    doi: "10.5269/bspm.81813",
    description: "Exploring how antipredator behaviors and harvesting interact to change population dynamics."
  }
];

export default function Highlights() {
  return (
    <div className="pt-32 pb-24 px-6 bg-[#FDFCFB]">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-20"
        >
          <span className="text-academic-gold font-bold uppercase text-xs tracking-widest mb-4 inline-block">Featured Work</span>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-academic-navy mb-6">Recent Highlights</h1>
          <p className="text-slate-500 max-w-2xl mx-auto">
            A curated selection of the most significant recent research contributions in nonlinear dynamical systems and ecological modelling.
          </p>
        </motion.div>

        <div className="space-y-12">
          {highlights.map((pub, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="group relative bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 overflow-hidden"
            >
              <div className="absolute top-0 right-0 -mt-8 -mr-8 w-40 h-40 bg-academic-gold/5 rounded-full blur-3xl group-hover:bg-academic-gold/10 transition-colors"></div>
              
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 bg-academic-gold border border-white/20 rounded-2xl flex items-center justify-center text-white shadow-lg">
                    <Star size={24} fill="currentColor" />
                  </div>
                  <span className="text-academic-navy/40 font-bold text-xs uppercase tracking-widest">Selected Publication 2026</span>
                </div>

                <h2 className="font-serif text-2xl md:text-3xl font-bold text-academic-navy mb-4 group-hover:text-academic-gold transition-colors leading-tight">
                  {pub.title}
                </h2>

                <p className="text-slate-600 mb-8 leading-relaxed italic">
                  {pub.description}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-8 border-t border-slate-50">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-slate-700 font-medium">
                      <FileText size={18} className="text-academic-gold" />
                      {pub.journal}
                    </div>
                    <div className="flex items-center gap-3 text-slate-500 text-sm">
                      <User size={16} />
                      {pub.authors}
                    </div>
                  </div>
                  
                  <div className="flex items-end justify-start md:justify-end">
                    <a 
                      href={`https://doi.org/${pub.doi}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-2 px-6 py-3 bg-academic-navy text-white rounded-full hover:bg-academic-gold transition-all text-sm font-bold shadow-md"
                    >
                      View Full Paper
                      <ExternalLink size={16} />
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <Link 
            to="/publications"
            className="inline-flex items-center gap-2 text-academic-navy font-bold hover:text-academic-gold transition-colors group"
          >
            View All Publications
            <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </motion.div>
      </div>
    </div>
  );
}
