import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { GraduationCap, Award, BookOpen, ChevronsDown, Star } from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center bg-academic-navy text-white pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-academic-navy"></div>
          <div className="w-full h-full opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:40px_40px]"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
          <div className="flex flex-col md:flex-row gap-12 lg:gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="md:w-3/5"
            >
              <span className="inline-block text-academic-gold uppercase text-xs font-bold tracking-[0.3em] mb-6">
                Assistant Professor of Mathematics
              </span>
              <h1 className="font-serif text-5xl md:text-7xl font-bold mb-6 tracking-tight leading-[1.1] text-white">
                Dr. Ankur Jyoti <br />
                <span className="text-academic-gold">Kashyap</span>
              </h1>
              <p className="text-lg md:text-xl text-slate-300 max-w-xl mb-10 leading-relaxed font-light">
                Specializing in nonlinear dynamical systems, mathematical modelling, and the complex dynamics of eco-epidemiological interactions.
              </p>
              <div className="flex flex-wrap gap-4">
                <a 
                  href="#qualifications"
                  className="px-8 py-4 bg-academic-gold text-white font-semibold rounded-full hover:bg-opacity-90 transition-all flex items-center gap-2 group shadow-lg shadow-academic-gold/20"
                >
                  Academic Background
                  <ChevronsDown size={18} className="group-hover:translate-y-1 transition-transform" />
                </a>
                <a 
                  href="/research"
                  className="px-8 py-4 border border-white/30 text-white font-semibold rounded-full hover:bg-white/10 transition-all"
                >
                  View Research
                </a>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9, x: 30 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative md:w-2/5 w-full max-w-md md:max-w-none"
            >
              <div className="absolute -inset-4 bg-academic-gold/30 rounded-[4rem] blur-3xl opacity-50"></div>
              <div className="relative rounded-[3rem] overflow-hidden border-4 border-white/10 shadow-2xl group">
                <img 
                  src="https://9fe1d4d4.delivery.rocketcdn.me/wp-content/uploads/2023/08/2-2.jpg" 
                  alt="Dr. Ankur Jyoti Kashyap" 
                  className="w-full aspect-[4/5] object-cover contrast-[1.08] brightness-[1.05] filter saturate-[1.15] sepia-[0.05] drop-shadow-2xl transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-academic-navy/70 via-transparent to-transparent opacity-80"></div>
                
                {/* Status Indicator */}
                <div className="absolute top-6 right-6 px-4 py-2 bg-white/20 backdrop-blur-md border border-white/30 rounded-full text-[10px] font-bold text-white uppercase tracking-widest shadow-xl">
                  Active Faculty
                </div>

                {/* Academic Badge Overlay */}
                <div className="absolute bottom-8 left-8 right-8 p-5 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl shadow-2xl">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-academic-navy rounded-xl flex items-center justify-center text-academic-gold shadow-inner">
                      <GraduationCap size={20} />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-widest text-white font-black opacity-90">Ph.D. Mathematics</p>
                      <p className="text-sm text-white font-medium">Assistant Professor, GCU</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Decorative elements - mathematical vibe */}
              <div className="absolute -bottom-12 -left-12 w-32 h-32 border-2 border-academic-gold/20 rounded-full -z-10 animate-pulse"></div>
              <div className="absolute -top-12 -right-12 w-24 h-24 bg-academic-gold/10 rounded-full -z-10 blur-xl"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats/Quick Glance */}
      <section className="py-20 px-6 bg-white border-y border-slate-100">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="flex flex-col items-center text-center p-8 bg-slate-50 rounded-3xl hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-academic-navy text-white rounded-2xl flex items-center justify-center mb-6">
              <GraduationCap size={32} />
            </div>
            <h3 className="font-serif text-xl font-bold mb-2">Academician</h3>
            <p className="text-slate-500 text-sm">Committed to excellence in teaching and curriculum development in higher education.</p>
          </div>
          <div className="flex flex-col items-center text-center p-8 bg-slate-50 rounded-3xl hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-academic-gold text-white rounded-2xl flex items-center justify-center mb-6">
              <BookOpen size={32} />
            </div>
            <h3 className="font-serif text-xl font-bold mb-2">Researcher</h3>
            <p className="text-slate-500 text-sm">Investigating complex mathematical structures with multiple published works in peer-reviewed journals.</p>
          </div>
          <Link to="/highlights" className="flex flex-col items-center text-center p-8 bg-slate-50 rounded-3xl hover:shadow-xl transition-all group">
            <div className="w-16 h-16 bg-academic-gold text-white rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <Star size={32} fill="currentColor" />
            </div>
            <h3 className="font-serif text-xl font-bold mb-2">Recent Highlights</h3>
            <p className="text-slate-500 text-sm">A selection of my most impactful recent research and scientific contributions.</p>
          </Link>
        </div>
      </section>

      {/* Qualifications Section */}
      <section id="qualifications" className="py-24 px-6 bg-[#FDFCFB]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-16">
            <div className="md:w-1/3 space-y-8">
              <span className="text-academic-gold font-bold uppercase text-xs tracking-widest">Credentials</span>
              <h2 className="font-serif text-4xl font-bold mt-4 mb-6 leading-tight">Academic Qualifications</h2>
              
              <p className="text-slate-600 leading-relaxed text-justify md:text-lg">
                Dr. Kashyap specializes in nonlinear dynamical systems and mathematical modelling. His research explores ecological and epidemiological complex systems using techniques from dynamical systems theory. His current interests include the impact of psychological and behavioral changes in animals on life-history dynamics and the mathematical modelling of infectious diseases. He is deeply interested in bifurcation analysis, particularly codimension-two bifurcations, as well as fractional differential equation models and their dynamical behavior.
              </p>
            </div>
            <div className="md:w-2/3 space-y-8">
              {[
                {
                  degree: "Ph.D. in Mathematics",
                  institution: "Gauhati University",
                  year: "2018 - 2022",
                  details: "Thesis: \"A Study on Some Dynamical Systems Representing Eco-Epidemiological Predator-Prey Interactions\".\nSupervisor: Prof. Hemanta Kumar Sarmah."
                },
                {
                  degree: "M.Sc. in Pure Mathematics",
                  institution: "Gauhati University, Jalukbari, Guwahati, Assam",
                  year: "2015 - 2017",
                  details: "Postgraduate studies in Higher Mathematics"
                },
                {
                  degree: "B.Sc. in Mathematics",
                  institution: "Jagannath Barooah College, Jorhat (Dibrugarh University)",
                  year: "2011 - 2014",
                  details: "Undergraduate Honours in Mathematics"
                }
              ].map((item, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-8 bg-white border border-slate-100 rounded-2xl shadow-sm hover:shadow-md transition-shadow group"
                >
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-serif text-xl font-bold text-academic-navy group-hover:text-academic-gold transition-colors">{item.degree}</h3>
                    <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-xs font-bold">{item.year}</span>
                  </div>
                  <p className="text-slate-700 font-medium mb-1">{item.institution}</p>
                  <p className="text-slate-500 text-sm whitespace-pre-line">{item.details}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Teaching Experience */}
      <section className="py-24 px-6 bg-academic-navy text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 bg-[radial-gradient(circle_at_center,_white_1px,_transparent_1px)] [background-size:20px_20px] -rotate-12 transform translate-x-20"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row-reverse gap-16">
            <div className="md:w-1/3">
              <span className="text-academic-gold font-bold uppercase text-xs tracking-widest">Professional Journey</span>
              <h2 className="font-serif text-4xl font-bold mt-4 mb-6 leading-tight">Teaching Experience</h2>
              <p className="text-slate-400 mb-8">
                With years of classroom excellence, Dr. Kashyap has mentored hundreds of students at undergraduate and postgraduate levels.
              </p>
            </div>
            <div className="md:w-2/3 space-y-8">
              {[
                {
                  role: "Assistant Professor (Mathematics)",
                  institution: "Girijananda Chowdhury University: Guwahati, Assam, IN",
                  period: "2023-08-16 - Present",
                  tasks: [
                    "Teaching Undergraduate and Postgraduate Mathematics students.",
                    "Supervising student projects and research work.",
                    "Involved in Departmental Administrative and Academic activities."
                  ]
                },
                {
                  role: "Assistant Professor (Mathematics)",
                  institution: "Royal Global University: Guwahati, Assam, IN",
                  period: "2022-05-16 - 2023-08-15",
                  tasks: [
                    "Instruction of core mathematics courses for undergraduate and postgraduate students.",
                    "Curriculum development and examination management.",
                    "Engagement in institutional research and extracurricular mentorship."
                  ]
                }
              ].map((item, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-8 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm"
                >
                   <div className="flex justify-between items-start mb-4">
                    <h3 className="font-serif text-xl font-bold text-white">{item.role}</h3>
                    <span className="text-academic-gold font-bold text-xs">{item.period}</span>
                  </div>
                  <p className="text-slate-300 font-medium mb-4">{item.institution}</p>
                  <ul className="space-y-2">
                    {item.tasks.map((task, tidx) => (
                      <li key={tidx} className="text-slate-400 text-sm flex items-center gap-2">
                        <div className="w-1 h-1 bg-academic-gold rounded-full"></div>
                        {task}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
