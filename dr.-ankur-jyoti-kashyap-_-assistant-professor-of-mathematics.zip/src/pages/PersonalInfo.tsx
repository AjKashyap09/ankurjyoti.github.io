import { motion } from "motion/react";
import { Mail, MapPin, Building, Globe, Linkedin, FlaskConical } from "lucide-react";

export default function PersonalInfo() {
  return (
    <div className="pt-32 pb-24 px-6 bg-[#FDFCFB]">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-16"
        >
          {/* Left Column: Image and Basic Details */}
          <div className="lg:col-span-4">
            <div className="sticky top-32 px-4">
              <div className="space-y-6">
                <div>
                  <h1 className="font-serif text-3xl font-bold text-academic-navy mb-1">Dr. Ankur Jyoti Kashyap</h1>
                  <p className="text-academic-gold font-semibold text-sm tracking-wide uppercase">Assistant Professor</p>
                </div>

                <div className="space-y-4 pt-4 border-t border-slate-100">
                  <div className="flex items-center gap-3 text-slate-600 text-sm">
                    <Building className="text-academic-navy" size={18} />
                    <span>Girijananda Chowdhury University</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-600 text-sm">
                    <MapPin className="text-academic-navy" size={18} />
                    <span>Azara, Guwahati, Assam, India</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-600 text-sm">
                    <Mail className="text-academic-navy" size={18} />
                    <span>ajkashyap.maths@gmail.com</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-600 text-sm">
                    <Globe className="text-academic-navy" size={18} />
                    <span>www.gcu.ac.in</span>
                  </div>
                </div>

                <div className="flex gap-4 pt-6">
                  <a 
                    href="https://in.linkedin.com/in/ankur-jyoti-kashyap-aba079149" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-academic-navy text-white flex items-center justify-center hover:bg-academic-gold transition-colors"
                  >
                    <Linkedin size={18} />
                  </a>
                  <a 
                    href="https://www.google.com/url?q=https%3A%2F%2Fwww.researchgate.net%2Fprofile%2FAnkur-Kashyap-4&sa=D" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center hover:bg-[#00ccbb] hover:text-white transition-colors"
                    title="ResearchGate"
                  >
                    <FlaskConical size={18} />
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: In-depth Information */}
          <div className="lg:col-span-8">
            <section className="mb-16">
              <h2 className="font-serif text-3xl font-bold mb-8 pb-2 border-b-2 border-academic-gold inline-block">Ph.D. Thesis Details</h2>
              <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-academic-gold/5 rounded-bl-full"></div>
                <div className="space-y-4 relative z-10">
                  <div>
                    <h3 className="text-academic-gold font-bold uppercase text-[10px] tracking-widest mb-1">Thesis Title</h3>
                    <p className="text-academic-navy font-serif text-xl font-bold italic leading-relaxed">
                      "A Study on Some Dynamical Systems Representing Eco-Epidemiological Predator-Prey Interactions"
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-200">
                    <div>
                      <h3 className="text-slate-400 font-bold uppercase text-[10px] tracking-widest mb-1">Supervisor</h3>
                      <p className="text-slate-700 font-medium capitalize">Prof. Hemanta Kumar Sarmah</p>
                      <p className="text-slate-500 text-xs mt-0.5">Dept. of Mathematics, Gauhati University</p>
                    </div>
                    <div>
                      <h3 className="text-slate-400 font-bold uppercase text-[10px] tracking-widest mb-1">External Examiner</h3>
                      <p className="text-slate-700 font-medium capitalize">Prof. Mridula Kanoria</p>
                      <p className="text-slate-500 text-xs mt-0.5">Retd. Prof., University of Calcutta</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6">
                    <div className="bg-white/60 p-3 rounded-xl border border-slate-100">
                      <p className="text-[10px] text-slate-400 uppercase font-black">Submission</p>
                      <p className="text-sm font-bold text-academic-navy">21/02/2022</p>
                    </div>
                    <div className="bg-white/60 p-3 rounded-xl border border-slate-100">
                      <p className="text-[10px] text-slate-400 uppercase font-black">Defense</p>
                      <p className="text-sm font-bold text-academic-navy">26/08/2022</p>
                    </div>
                    <div className="bg-white/60 p-3 rounded-xl border border-slate-100">
                      <p className="text-[10px] text-academic-gold uppercase font-black">Awarded</p>
                      <p className="text-sm font-bold text-academic-navy">01/09/2022</p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-16">
              <h2 className="font-serif text-3xl font-bold mb-6 pb-2 border-b-2 border-academic-gold inline-block">Biography</h2>
              <div className="space-y-6 text-slate-700 leading-relaxed text-justify">
                <p>
                  Dr. Ankur Jyoti Kashyap is a dedicated mathematician and educator currently serving as an Assistant Professor in the Department of Mathematics at Girijananda Chowdhury University (GCU), Assam. He earned his Ph.D. in Mathematics from Gauhati University (2018-2022) with a research focus on Eco-Epidemiological Predator-Prey Interactions using Dynamical Systems.
                </p>
                <p>
                  Originally from Assam, Dr. Kashyap has spent his career contributing to the educational landscape of the region. He believes in the power of mathematics as a universal language that underpins technological and scientific progress. His teaching philosophy emphasizes conceptual clarity and the development of problem-solving skills among his students.
                </p>
                <p>
                  In addition to his teaching responsibilities, Dr. Kashyap is actively involved in institutional development and contributes regularly to the academic growth of GCU through various administrative and research initiatives.
                </p>
              </div>
            </section>

            <section className="mb-16">
              <h2 className="font-serif text-3xl font-bold mb-8 pb-2 border-b-2 border-academic-gold inline-block">Professional Experience</h2>
              <div className="space-y-8">
                {[
                  {
                    company: "Girijananda Chowdhury University",
                    location: "Guwahati, Assam, IN",
                    role: "Assistant Professor (Mathematics)",
                    period: "Aug 2023 - Present"
                  },
                  {
                    company: "Royal Global University",
                    location: "Guwahati, Assam, IN",
                    role: "Assistant Professor (Mathematics)",
                    period: "May 2022 - Aug 2023"
                  }
                ].map((exp, i) => (
                  <div key={i} className="flex gap-6 group">
                    <div className="flex flex-col items-center">
                      <div className="w-4 h-4 rounded-full border-2 border-academic-gold group-hover:bg-academic-gold transition-colors"></div>
                      <div className="w-px flex-1 bg-slate-200 mt-2 mb-2"></div>
                    </div>
                    <div className="pb-8">
                      <span className="text-xs font-bold text-academic-gold uppercase tracking-tighter">{exp.period}</span>
                      <h3 className="font-serif text-2xl font-bold text-academic-navy mt-1">{exp.role}</h3>
                      <p className="text-slate-600 font-medium">{exp.company}</p>
                      <p className="text-slate-400 text-sm">{exp.location}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section className="mb-16">
              <h2 className="font-serif text-3xl font-bold mb-8 pb-2 border-b-2 border-academic-gold inline-block">Awards & Recognition</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  { title: "Promising Researcher Award 2024", body: "Girijananda Chowdhury University" },
                  { title: "Young Researcher Award 2025", body: "Girijananda Chowdhury University" }
                ].map((award, i) => (
                  <div key={i} className="p-6 bg-white border-l-4 border-academic-gold shadow-sm rounded-r-xl">
                    <h3 className="font-serif text-xl font-bold text-academic-navy mt-1 mb-2">{award.title}</h3>
                    <p className="text-sm text-slate-600">{award.body}</p>
                  </div>
                ))}
              </div>
            </section>

            <section>
              <h2 className="font-serif text-3xl font-bold mb-8 pb-2 border-b-2 border-academic-gold inline-block">Memberships</h2>
              <ul className="space-y-4">
                {[
                  "IAENG"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-4 p-4 bg-slate-50 rounded-xl hover:bg-white border border-transparent hover:border-slate-100 transition-all">
                    <div className="w-2 h-2 rounded-full bg-academic-gold"></div>
                    <span className="text-slate-700 font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </section>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
