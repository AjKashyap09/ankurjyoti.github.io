import { motion } from "motion/react";
import { Presentation, MapPin, Calendar, Monitor, Award, Mic2, Quote } from "lucide-react";

const invitedTalks = [
  {
    title: "Understanding Climate Oscillations: Exploring Memory Effects in the El Niño–Southern Oscillation",
    event: "National Conference on Reimagining the Global Environment: Opportunities and Challenges in India (ReGEO-2025)",
    location: "Gauhati University, Assam, India",
    date: "November 6–7, 2025",
    type: "Invited Talk"
  },
  {
    title: "Nonlinear Dynamical Systems and Mathematical Modelling: Theory, Applications, and Simulations",
    event: "Online Faculty Development Program on 'Transformative Paradigm & Emerging Trends in Applied Sciences & Engineering'",
    location: "Online / MIT ADT University",
    date: "December 1–12, 2025",
    type: "Keynote Talk",
    organizer: "MIT School of Computing, MIT ADT University"
  }
];

const workshops = [
  {
    title: "Eight-Day Online Training on NEP Orientation & Sensitization Programme",
    organizer: "UGC-MMTTC, Gauhati University",
    location: "Online",
    date: "December 3-12, 2025",
    description: "Organised by UGC-Malaviya Mission Teacher Training Centre."
  },
  {
    title: "Five-day FDP on 'RECENT ADVANCEMENT IN FLUID MECHANICS AND OPTIMIZATION (RAFMO)'",
    organizer: "Amity Institute of Applied Sciences, Amity University Jharkhand",
    location: "Online",
    date: "July 14-18, 2025",
    description: "Faculty Development Programme focused on fluid dynamics and optimization techniques."
  },
  {
    title: "Workshop on 'MATHEMATICAL MODELS IN EPIDEMIOLOGY (MME)' Course",
    organizer: "BCAM - Basque Center for Applied Mathematics, Spain",
    location: "Online / Bilbao, Spain",
    date: "March 25 - June 22, 2022",
    description: "Intensive course organized by the MTB group at BCAM."
  },
  {
    title: "Five-day International Online Workshop on 'Advanced Numerical Techniques for Differential Equations (ANTDE-22)'",
    organizer: "Malaviya National Institute of Technology (MNIT), Jaipur, India",
    location: "Online",
    date: "June 6-10, 2022",
    description: "Focussed on advanced numerical methods for solving differential equations."
  },
  {
    title: "e-STC on 'Recent development in Numerical Methods for Partial differential equations (RD-NMPDE 2022)'",
    organizer: "National Institute of Technology (NIT) Hamirpur, Himachal Pradesh, India",
    location: "Online",
    date: "May 30 - June 3, 2022",
    description: "Short Term Course on recent developments in numerical methods for PDEs."
  },
  {
    title: "International Workshop on 'Networks and Dynamical Systems, 2021'",
    organizer: "Indian Institute of Technology (IIT) Madras",
    location: "Online",
    date: "August 25-28, 2021",
    description: "Organized by the Complex Systems and Dynamics group."
  }
];

const conferences = [
  {
    title: "8th International Conference on Mathematical Modelling, Applied Analysis and Computation (ICMMAAC-25)",
    role: "Paper Presentation",
    location: "JECRC University, Jaipur (Raj.), India",
    date: "August 1-3, 2025",
    description: "Coral Ecosystem Dynamics: Modelling CoTs and Wrasse Interactions with Coral Disease and Commensalism"
  },
  {
    title: "6th International Conference on Mathematical Modelling, Applied Analysis and Computation (ICMMAAC-23)",
    role: "Paper Presentation",
    location: "JECRC University, Jaipur (Raj.), India",
    date: "August 3-5, 2023",
    description: "A Fear-Affected Stage-Structured Predator-Prey Model"
  },
  {
    title: "International Conference on Nonlinear Analysis and Applications-2022 (ICNAA-2022)",
    role: "Paper Presentation",
    location: "Assam Don Bosco University / Online (India and Mexico)",
    date: "November 22-23, 2022",
    description: "Complex dynamics in an eco-epidemiological model due to non-consumptive risks"
  },
  {
    title: "International Conference on DYNAMICAL SYSTEMS, CONTROL AND THEIR APPLICATIONS (ICDSCA-22)",
    role: "Paper Presentation",
    location: "IIT Roorkee, India",
    date: "July 1-3, 2022",
    description: "Center manifolds, Hopf bifurcation in an epidemic model"
  },
  {
    title: "13th Conference on Dynamical Systems Applied to Biology and Natural Sciences (DSABNS 2022)",
    role: "Participant",
    location: "Basque Center for Applied Mathematics (BCAM), Spain / Online",
    date: "February 8-11, 2022",
    description: "Attended the conference organized by the Mathematical and Theoretical Biology Group."
  },
  {
    title: "4th International Conference on Mathematical Modelling, Applied Analysis and Computation (ICMMAAC-21)",
    role: "Paper Presentation",
    location: "JECRC University, Jaipur (Raj.), India",
    date: "August 5-7, 2021",
    description: "Dynamical Behaviour in a Predator-Prey System with Nonlinear Harvesting"
  },
  {
    title: "3rd International Conference on Mathematical Modelling, Applied Analysis and Computation (ICMMAAC-20)",
    role: "Paper Presentation",
    location: "JECRC University, Jaipur (Raj.), India",
    date: "August 7-9, 2021",
    description: "A Fractional-Order Eco-Epidemiological Model With Fear Effect"
  },
  {
    title: "International conference on Advances in Differential Equations and Numerical Analysis (ADENA)",
    role: "Paper Presentation",
    location: "IIT Guwahati, India",
    date: "October 12-15, 2020",
    description: "Dynamics of an Eco-Epidemiological Model with Nonlinear Incidence Rate and Fear Effect"
  },
  {
    title: "International Conference on Mathematical Modelling in Applied Sciences (ICMMAS2020)",
    role: "Paper Presentation",
    location: "Dibrugarh University, Assam, India",
    date: "June 28-30, 2020",
    description: "An Eco-Epidemiological Model With a Predating Scavenger"
  },
  {
    title: "International Conference on Advances in Mathematics and Computing (ICAMC-2020)",
    role: "Paper Presentation",
    location: "VSSUT, Burla, Odisha, India",
    date: "February 7-8, 2020",
    description: "Coexistence and stability analysis of predator-prey model with ratio-dependent functional response where both the population are affected by disease"
  }
];

export default function Presentations() {
  return (
    <div className="pt-32 pb-24 px-6 bg-[#FDFCFB]">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-20 text-center"
        >
          <span className="text-academic-gold font-bold uppercase text-xs tracking-widest mb-4 inline-block">Engagement & Dissemination</span>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-academic-navy mb-6">Conferences & Talks</h1>
          <p className="text-slate-500 max-w-2xl mx-auto italic">
            A comprehensive record of invited talks, conference presentations, and professional workshop participation.
          </p>
        </motion.div>

        {/* Invited Talks Section */}
        <section className="mb-24">
          <div className="flex items-center gap-4 mb-12">
            <h2 className="font-serif text-3xl font-bold text-academic-navy">Invited Talks</h2>
            <div className="h-px flex-1 bg-slate-200"></div>
          </div>
          <div className="grid grid-cols-1 gap-12">
            {invitedTalks.map((talk, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="relative p-10 bg-white border border-slate-100 rounded-[3rem] shadow-sm hover:shadow-2xl transition-all duration-500 group"
              >
                <div className="absolute top-0 right-0 -mt-6 -mr-6 w-32 h-32 bg-academic-navy/5 rounded-full blur-3xl group-hover:bg-academic-gold/10 transition-colors"></div>
                
                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="w-14 h-14 bg-academic-navy rounded-2xl flex items-center justify-center text-white shadow-lg group-hover:bg-academic-gold transition-colors">
                      <Mic2 size={24} />
                    </div>
                    <div>
                      <span className="text-academic-gold font-bold text-xs uppercase tracking-tighter mb-1 block">
                        {talk.type}
                      </span>
                      <div className="h-1 w-12 bg-slate-200 rounded-full"></div>
                    </div>
                  </div>

                  <h3 className="font-serif text-2xl md:text-3xl font-bold text-academic-navy mb-6 leading-tight">
                    "{talk.title}"
                  </h3>

                  <div className="space-y-4">
                    <p className="text-slate-700 font-medium text-lg leading-relaxed">
                      {talk.event}
                    </p>
                    {talk.organizer && (
                      <p className="text-slate-500 text-sm">
                        <span className="text-academic-navy font-bold mr-2">Organizer:</span>
                        {talk.organizer}
                      </p>
                    )}
                    <div className="flex flex-wrap gap-6 mt-8 pt-8 border-t border-slate-50">
                      <div className="flex items-center gap-2 text-slate-500">
                        <MapPin size={18} className="text-academic-gold" />
                        <span className="text-sm">{talk.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-500">
                        <Calendar size={18} className="text-academic-gold" />
                        <span className="text-sm">{talk.date}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute bottom-10 right-10 opacity-5 group-hover:opacity-10 transition-opacity">
                  <Quote size={120} />
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Workshops & Training Section */}
        <section className="mb-24">
          <div className="flex items-center gap-4 mb-12">
            <h2 className="font-serif text-3xl font-bold text-academic-navy">Workshops & Training</h2>
            <div className="h-px flex-1 bg-slate-200"></div>
          </div>
          <div className="space-y-8">
            {workshops.map((workshop, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="group p-8 bg-slate-50 border border-slate-100 rounded-[2.5rem] shadow-sm hover:shadow-xl transition-all duration-300 relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-8 text-slate-100 group-hover:text-academic-gold/20 transition-colors">
                  <Award size={80} />
                </div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center text-academic-navy group-hover:bg-academic-navy group-hover:text-white transition-all">
                      <Monitor size={20} />
                    </div>
                    <span className="text-xs font-bold text-academic-gold uppercase tracking-widest">Workshop</span>
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-academic-navy mb-4 group-hover:text-academic-gold transition-colors">
                    {workshop.title}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div className="flex items-center gap-2 text-slate-500 text-sm">
                      <Award size={16} className="text-academic-gold shrink-0" />
                      <span className="font-medium text-slate-700">{workshop.organizer}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-500 text-sm">
                      <MapPin size={16} className="text-academic-gold shrink-0" />
                      {workshop.location}
                    </div>
                    <div className="flex items-center gap-2 text-slate-500 text-sm">
                      <Calendar size={16} className="text-academic-gold shrink-0" />
                      {workshop.date}
                    </div>
                  </div>
                  <p className="text-slate-600 text-sm italic leading-relaxed pl-4 border-l-2 border-academic-gold/30">
                    {workshop.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Conference Presentations Section */}
        <section>
          <div className="flex items-center gap-4 mb-12">
            <h2 className="font-serif text-3xl font-bold text-academic-navy">Conference Presentations</h2>
            <div className="h-px flex-1 bg-slate-200"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {conferences.map((conf, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="bg-white border border-slate-100 p-8 rounded-3xl shadow-sm hover:shadow-xl transition-all group overflow-hidden relative"
              >
                <div className="absolute -right-4 -top-4 w-24 h-24 bg-academic-navy/5 rounded-full blur-2xl group-hover:bg-academic-gold/10 transition-colors"></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-3 bg-academic-navy/5 rounded-2xl text-academic-navy group-hover:bg-academic-navy group-hover:text-white transition-colors">
                      <Presentation size={24} />
                    </div>
                    <span className="px-3 py-1 bg-academic-gold/10 text-academic-gold text-[10px] font-bold uppercase rounded-lg tracking-wider">
                      {conf.role}
                    </span>
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-academic-navy mb-4 leading-tight group-hover:text-academic-gold transition-colors">
                    {conf.title}
                  </h3>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2 text-slate-500 text-sm">
                      <MapPin size={16} className="text-academic-gold" />
                      {conf.location}
                    </div>
                    <div className="flex items-center gap-2 text-slate-500 text-sm">
                      <Calendar size={16} className="text-academic-gold" />
                      {conf.date}
                    </div>
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed border-t border-slate-50 pt-4 italic">
                    "{conf.description}"
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
