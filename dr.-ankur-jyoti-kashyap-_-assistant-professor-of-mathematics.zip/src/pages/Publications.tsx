import { motion } from "motion/react";
import { FileText, ExternalLink, Calendar, User } from "lucide-react";

const publications = [
  {
    title: "A Mathematical–Dynamical Framework for Coral–Zooxanthellae Interactions under Vibrio-Induced Bleaching",
    journal: "Chinese Journal of Physics",
    year: "2026",
    authors: "Suruj Lekharu, Ankur Jyoti Kashyap",
    doi: "10.1016/j.cjph.2026.04.040",
    type: "Journal Article",
    metrics: "SCIE",
    impactFactor: "4.6"
  },
  {
    title: "Deterministic study of an Eco-epidemiological Model with Prey Refuge and Predator Harvesting",
    journal: "Boletim Da Sociedade Paranaense de Matemática",
    year: "2026",
    authors: "Kahuwa Kuwali Barman, Ankur Jyoti Kashyap, Hemanta Kumar Sarmah",
    doi: "10.5269/bspm.81950",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI",
    impactFactor: "0.04"
  },
  {
    title: "Dynamical Analysis of a Leslie-Gower Type Harvesting Model Incorporating Nonlinear Harvesting and Fear Effect",
    journal: "Boletim Da Sociedade Paranaense de Matemática",
    year: "2026",
    authors: "Ankur Jyoti Kashyap, Suruj Lekharu, Tarini Kumar Dutta",
    doi: "10.5269/bspm.81813",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI",
    impactFactor: "0.04"
  },
  {
    title: "Modelling a delay-driven eco-epidemiological system with fear and migration under ratio-dependent predation",
    journal: "Mathematics and Computers in Simulation, ELSEVIER",
    year: "2026",
    authors: "Kahuwa Kuwali Barman, Ankur Jyoti Kashyap, Hemanta Kumar Sarmah",
    doi: "10.1016/j.matcom.2026.01.002",
    type: "Journal Article",
    metrics: "SCIE",
    impactFactor: "4.4"
  },
  {
    title: "A Leslie-Gower Model for prey harvesting with predator cooperation and fear responses",
    journal: "Boletim Da Sociedade Paranaense de Matemática",
    year: "2025",
    authors: "Mustak Euchuf, Ankur Jyoti Kashyap, Anuradha Devi",
    doi: "10.5269/bspm.78991",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI",
    impactFactor: "0.04"
  },
  {
    title: "Combined effects of antipredator behaviors and cooperative hunting in a stage-structured predator-prey model",
    journal: "Mathematical Modelling and Control",
    year: "2025",
    authors: "Ankur Jyoti Kashyap, Fengde Chen, Fanitsha Mohan, Anuradha Devi, Hemanta Kumar Sarmah",
    doi: "10.3934/mmc.2025023",
    type: "Journal Article",
    metrics: "ESCI, SCOPUS",
    impactFactor: "2.7"
  },
  {
    title: "Nonlinear dynamical analysis of a fractional-order El Niño Southern Oscillation system",
    journal: "The European Physical Journal Plus",
    year: "2025",
    authors: "Angana Das Mahapatra, Ankur Jyoti Kashyap, Gautam Choudhury, Santu Das, Hemanta Kumar Sarmah",
    doi: "10.1140/epjp/s13360-025-06617-1",
    type: "Journal Article",
    metrics: "SCIE",
    impactFactor: "2.9"
  },
  {
    title: "A Stage-Structured Prey-Predator Interaction Model with the Impact of Fear and Hunting Cooperation",
    journal: "International Journal of Biomathematics, World Scientific",
    year: "2024",
    authors: "Kashyap, A.J., Doley, D., Chen, F. and Bordoloi, A.J.",
    doi: "10.1142/S1793524524501109",
    type: "Journal Article",
    metrics: "SCIE",
    impactFactor: "2.4"
  },
  {
    title: "Dynamic Behaviors of a Non-autonomous Single-Species Feedback Control System",
    journal: "Engineering Letters",
    year: "2024",
    authors: "Qin Yue, Ankur Jyoti Kashyap, Fengde Chen",
    doi: "N/A",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI",
    impactFactor: "0.6"
  },
  {
    title: "Complex dynamics in a predator-prey model with fear affected transmission",
    journal: "Differential Equations and Dynamical Systems, Springer",
    year: "2024",
    authors: "Ankur Jyoti Kashyap, Hemanta Kumar Sarmah",
    doi: "10.1007/s12591-024-00698-7",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI",
    impactFactor: "1.0"
  },
  {
    title: "Dynamical behaviours of discrete amensalism system with fear effects on first species",
    journal: "Mathematical Biosciences and Engineering",
    year: "2024",
    authors: "Qianqian Li, Ankur Jyoti Kashyap, Qun Zhu, Fengde Chen",
    doi: "10.3934/mbe.2024035",
    type: "Journal Article",
    metrics: "SCIE, SCOPUS",
    impactFactor: "2.6"
  },
  {
    title: "Dynamical analysis of an anthrax disease model in animals with nonlinear transmission rate",
    journal: "Mathematical Modelling and Control",
    year: "2023",
    authors: "Ankur Jyoti Kashyap, Arnab Jyoti Bordoloi, Fanitsha Mohan, Anuradha Devi",
    doi: "10.3934/mmc.2023030",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI",
    impactFactor: "2.7"
  },
  {
    title: "Analysis of Stability, Sensitivity Index and Hopf Bifurcation of Eco-Epidemiological SIR Model under Pesticide Application",
    journal: "COMMUN. BIOMATH. SCI.",
    year: "2023",
    authors: "Balajied Me Syrti, Anuradha Devi, Ankur Jyoti Kashyap",
    doi: "10.5614/cbms.2023.6.2.4",
    type: "Journal Article",
    metrics: "SCOPUS Q2"
  },
  {
    title: "Dynamics Analysis of a Discrete-Time Commensalism Model with Additive Allee for the Host Species",
    journal: "Axioms",
    year: "2023",
    authors: "Yanbo Chong, Ankur Jyoti Kashyap, Shangming Chen, Fengde Chen",
    doi: "10.3390/axioms12111031",
    type: "Journal Article",
    metrics: "SCIE",
    impactFactor: "2.0"
  },
  {
    title: "Dynamical study of a predator–prey system with Michaelis–Menten type predator-harvesting",
    journal: "International Journal of Biomathematics",
    year: "2022",
    authors: "Ankur Jyoti Kashyap, Willy Govaerts, Debasish Bhattacharjee, Hemanta Kumar Sarmah",
    doi: "10.1142/S1793524522501352",
    type: "Journal Article",
    metrics: "SCIE",
    impactFactor: "2.129"
  },
  {
    title: "Bifurcation analysis of a predator-prey system with density dependent disease recovery",
    journal: "Filomat, University of Nis, Serbia",
    year: "2022",
    authors: "Ankur Jyoti Kashyap, Willy Govaerts, Debasish Bhattacharjee, Hemanta Kumar Sarmah",
    doi: "N/A",
    type: "Journal Article",
    metrics: "SCI"
  },
  {
    title: "A fractional model in exploring the role of fear in mass mortality of pelicans in the Salton Sea",
    journal: "IJOCTA",
    year: "2021",
    authors: "Ankur Jyoti Kashyap, Debasish Bhattacharjee, Hemanta Kumar Sarmah",
    doi: "10.11121/ijocta.2021.1123",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI"
  },
  {
    title: "Dynamics in a ratio-dependent eco-epidemiological predator-prey model having cross-species disease transmission",
    journal: "Communications in Mathematical Biology and Neuroscience",
    year: "2021",
    authors: "Debasish Bhattacharjee, Ankur Jyoti Kashyap, Hemanta Kumar Sarmah, Ranu Paul",
    doi: "N/A",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI"
  },
  {
    title: "Dynamical analysis of a predator-prey epidemiological model with density dependent disease recovery",
    journal: "Communications in Mathematical Biology and Neuroscience",
    year: "2020",
    authors: "Debasish Bhattacharjee, Ankur Jyoti Kashyap, Kaushik Dehingia, Hemanta Kumar Sarmah",
    doi: "N/A",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI"
  },
  {
    title: "An eco-epidemiological model with non-consumptive predation risk and a fatal disease in prey",
    journal: "Journal of Mathematical Sciences, Springer",
    year: "2024",
    authors: "Ankur Jyoti Kashyap, Hemanta Kumar Sarmah, Debasish Bhattacharjee",
    doi: "10.1007/s10958-024-07187-w",
    type: "Journal Article",
    metrics: "SCOPUS, ESCI"
  }
];

export default function Publications() {
  return (
    <div className="pt-32 pb-24 px-6 bg-[#FDFCFB]">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-20"
        >
          <span className="text-academic-gold font-bold uppercase text-xs tracking-widest mb-4 inline-block">Scholarship</span>
          <h1 className="font-serif text-5xl md:text-6xl font-bold text-academic-navy mb-6">Publications</h1>
          <p className="text-slate-500 max-w-2xl mx-auto italic">
            “Chaos: when the present determines the future, but the approximate present does not approximately determine the future.” — Edward Lorenz
          </p>
        </motion.div>

        <div className="space-y-16">
          {Object.entries(
            publications.reduce((acc, pub) => {
              const year = pub.year;
              if (!acc[year]) acc[year] = [];
              acc[year].push(pub);
              return acc;
            }, {} as Record<string, typeof publications>)
          )
          .sort(([yearA], [yearB]) => {
            if (yearA === "Latest/In Press") return -1;
            if (yearB === "Latest/In Press") return 1;
            return yearB.localeCompare(yearA);
          })
          .map(([year, yearPubs], yearIdx) => (
            <div key={year} className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="flex items-center gap-4 mb-8"
              >
                <h2 className="font-serif text-3xl font-bold text-academic-navy">{year}</h2>
                <div className="h-px flex-1 bg-slate-100"></div>
              </motion.div>
              
              <div className="space-y-6">
                {yearPubs.map((pub, idx) => (
                  <motion.div
                    key={`${year}-${idx}`}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    viewport={{ once: true }}
                    className="group p-8 bg-white border border-slate-100 rounded-[2rem] shadow-sm hover:shadow-xl transition-all duration-300 relative overflow-hidden"
                  >
                    {/* Highlight bar */}
                    <div className="absolute top-0 left-0 bottom-0 w-2 bg-academic-gold transform scale-y-0 group-hover:scale-y-100 transition-transform origin-top duration-300"></div>
      
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-3">
                          <span className="px-3 py-1 bg-academic-navy/5 text-academic-navy text-[10px] font-bold uppercase rounded-full tracking-wider group-hover:bg-academic-gold group-hover:text-white transition-colors">
                            {pub.type}
                          </span>
                        </div>
                        <h3 className="font-serif text-xl md:text-2xl font-bold text-academic-navy mb-3 group-hover:text-academic-gold transition-colors leading-snug">
                          {pub.title}
                        </h3>
                        <div className="space-y-2">
                          <p className="text-slate-600 font-medium flex items-center gap-2">
                            <FileText size={16} className="text-academic-gold" />
                            {pub.journal}
                          </p>
                          <div className="flex flex-wrap gap-x-4 gap-y-1">
                            <p className="text-slate-500 text-sm flex items-center gap-2 italic">
                              <User size={14} />
                              {pub.authors}
                            </p>
                            {pub.metrics && (
                              <p className="text-academic-navy/70 text-[11px] font-semibold flex items-center gap-1 border-l border-slate-200 pl-4">
                                <span className="text-academic-gold">Metrics:</span> {pub.metrics}
                              </p>
                            )}
                            {pub.impactFactor && (
                              <p className="text-academic-navy/70 text-[11px] font-semibold flex items-center gap-1 border-l border-slate-200 pl-4">
                                <span className="text-academic-gold">IF:</span> {pub.impactFactor}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
      
                      <div className="flex md:flex-col items-center gap-4">
                        {pub.doi !== "N/A" && (
                          <a 
                            href={`https://doi.org/${pub.doi}`}
                            target="_blank"
                            rel="noreferrer"
                            className="w-12 h-12 rounded-full border border-slate-200 flex items-center justify-center text-slate-400 hover:bg-academic-navy hover:text-white hover:border-academic-navy transition-all group/icon"
                            title="View DOI"
                          >
                            <ExternalLink size={20} className="group-hover/icon:scale-110 transition-transform" />
                          </a>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Impact Section */}
        <div className="mt-24 p-12 bg-academic-navy rounded-[3rem] text-white relative overflow-hidden text-center">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[radial-gradient(circle_at_center,_#ffffff_1px,_transparent_1px)] [background-size:20px_20px]"></div>
          <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="text-4xl font-serif font-bold text-academic-gold mb-2">20+</div>
              <div className="text-xs uppercase tracking-widest text-slate-400">Journal Articles</div>
            </div>
            <div>
              <div className="text-4xl font-serif font-bold text-academic-gold mb-2">250+</div>
              <div className="text-xs uppercase tracking-widest text-slate-400">Total Citations</div>
            </div>
            <div>
              <div className="text-4xl font-serif font-bold text-academic-gold mb-2">12+</div>
              <div className="text-xs uppercase tracking-widest text-slate-400">h-index</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
