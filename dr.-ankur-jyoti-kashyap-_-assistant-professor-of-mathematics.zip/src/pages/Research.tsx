import { motion } from "motion/react";
import { Search, Lightbulb, Code, Target, BookOpen, Waves, Thermometer, Activity, Infinity, GraduationCap } from "lucide-react";

export default function Research() {
  return (
    <div className="pt-32 pb-24 px-6 bg-[#FDFCFB]">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-24"
        >
          <span className="text-academic-gold font-bold uppercase text-xs tracking-widest mb-4 inline-block">Investigation</span>
          <h1 className="font-serif text-5xl md:text-7xl font-bold text-academic-navy mb-8">Research Portfolio</h1>
          <p className="text-slate-500 max-w-3xl mx-auto text-lg leading-relaxed font-light">
            My research focuses on the intersection of theoretical mathematical modeling and its practical applications in understanding physical and biological phenomena.
          </p>
        </motion.div>

        {/* Areas of Interest */}
        <section className="mb-32">
          <h2 className="font-serif text-3xl font-bold text-academic-navy mb-12 text-center">Core Research Areas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Infinity, title: "Nonlinear Dynamical Systems", desc: "Investigation into nonlinear behaviors, stability, and chaotic phenomena." },
              { icon: Lightbulb, title: "Mathematical Modelling", desc: "Constructing rigorous models for complex biological and physical systems." },
              { icon: Code, title: "Fractional Differential Equations", desc: "Studying fractional-order systems and their unique dynamical properties." },
              { icon: Thermometer, title: "Climate Change Dynamics", desc: "Mathematical analysis of environmental shifting and climatic interactions." },
              { icon: Waves, title: "Coral Reef Ecosystems", desc: "Modelling the sustainability and stress responses of marine ecosystems." },
              { icon: Activity, title: "Ecological Modelling", desc: "Exploring population dynamics, predation, and life-history evolution." },
              { icon: Target, title: "Epidemiological Modelling", desc: "Analysis of infectious disease spread and eco-epidemiological interactions." },
              { icon: Search, title: "Bifurcation Theory", desc: "Specializing in codimension-two bifurcations and phase transitions." }
            ].map((area, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.05 }}
                viewport={{ once: true }}
                className="p-8 bg-white border border-slate-100 rounded-[2rem] text-center shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all group"
              >
                <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-6 text-academic-navy group-hover:bg-academic-navy group-hover:text-white transition-all">
                  <area.icon size={28} />
                </div>
                <h3 className="font-serif text-lg font-bold mb-3 leading-tight">{area.title}</h3>
                <p className="text-slate-500 text-xs leading-relaxed">{area.desc}</p>
              </motion.div>
            ))}
          </div>
        </section>


        {/* Research Scholars */}
        <section className="mt-32">
          <h2 className="font-serif text-3xl font-bold text-academic-navy mb-12 text-center">Research Scholars</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              { name: "Dhanesh Doley", enrollment: "Monsoon 2023" },
              { name: "Suruj Lekharu", enrollment: "Monsoon 2023" },
              { name: "Bikashi Borah", enrollment: "Monsoon 2024" },
              { name: "Padmalochan Borah", enrollment: "Monsoon 2024" }
            ].map((scholar, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: idx % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="flex items-center gap-6 p-6 bg-white border border-slate-100 rounded-3xl shadow-sm hover:shadow-md transition-all group"
              >
                <div className="w-14 h-14 bg-academic-navy text-white rounded-2xl flex items-center justify-center font-bold text-xl group-hover:bg-academic-gold transition-colors">
                  {scholar.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-serif text-xl font-bold text-academic-navy">{scholar.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <GraduationCap size={14} className="text-academic-gold" />
                    <p className="text-slate-500 text-xs font-medium uppercase tracking-widest">
                      Enrolled: {scholar.enrollment}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Collaboration CTA */}
        <div className="mt-32 text-center bg-academic-gold/5 p-16 rounded-[3rem] border border-academic-gold/10">
          <BookOpen size={48} className="mx-auto text-academic-gold mb-6" />
          <h2 className="font-serif text-3xl font-bold text-academic-navy mb-4">Research Collaborations</h2>
          <p className="text-slate-600 max-w-xl mx-auto mb-8">
            I am always open to exploring new mathematical frontiers. If you are interested in collaborative research or have projects that align with my areas of interest, please feel free to get in touch.
          </p>
          <a href="/contact" className="px-10 py-4 bg-academic-navy text-white font-bold rounded-full hover:bg-academic-gold transition-colors inline-block">
            Propose Collaboration
          </a>
        </div>
      </div>
    </div>
  );
}
